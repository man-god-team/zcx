package com.crm.service;

import com.crm.entity.Zidongfenpei;

public interface ZidongfenpeiService {

	Zidongfenpei selectAllByZidongfenpei();
	Integer updateZidongfenpei(Zidongfenpei zidongfenpei);
}
