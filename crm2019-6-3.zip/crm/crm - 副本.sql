/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 50722
Source Host           : 127.0.0.1:3306
Source Database       : crm

Target Server Type    : MYSQL
Target Server Version : 50722
File Encoding         : 65001

Date: 2019-06-03 10:37:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dongtaixinxi
-- ----------------------------
DROP TABLE IF EXISTS `dongtaixinxi`;
CREATE TABLE `dongtaixinxi` (
  `dt_id` int(11) NOT NULL AUTO_INCREMENT,
  `dt_studentName` varchar(255) DEFAULT NULL,
  `dt_time` datetime DEFAULT NULL,
  `dt_yid` int(11) DEFAULT NULL,
  `dt_content` varchar(255) DEFAULT NULL,
  `dt_state` varchar(255) DEFAULT NULL,
  `dt_int1` int(255) DEFAULT NULL,
  `dt_string2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dongtaixinxi
-- ----------------------------
INSERT INTO `dongtaixinxi` VALUES ('11', '1', '2019-05-31 08:36:11', '1', 'adgda', '2', null, null);
INSERT INTO `dongtaixinxi` VALUES ('15', '老张2', '2019-06-02 10:29:44', '20', '这是大帅哥', '1', null, null);
INSERT INTO `dongtaixinxi` VALUES ('16', '老张2', '2019-06-02 10:30:31', '20', '我是经理', '1', null, null);
INSERT INTO `dongtaixinxi` VALUES ('17', '张旭', '2019-06-02 16:43:46', '3', '给我完善一下这个学生', '2', null, null);
INSERT INTO `dongtaixinxi` VALUES ('18', '张旭', '2019-06-02 16:44:09', '3', '再来个跟踪', '2', null, null);

-- ----------------------------
-- Table structure for model
-- ----------------------------
DROP TABLE IF EXISTS `model`;
CREATE TABLE `model` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `m_name` varchar(255) DEFAULT NULL,
  `m_parentId` int(11) DEFAULT NULL,
  `m_path` varchar(255) DEFAULT NULL,
  `m_weight` int(11) DEFAULT NULL,
  `m_weitghtDescribe` varchar(255) DEFAULT NULL,
  `m_ops` varchar(255) DEFAULT NULL,
  `m_exitInt` int(11) DEFAULT NULL,
  `m_exitString` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of model
-- ----------------------------
INSERT INTO `model` VALUES ('1', '管理员', '0', '', '10', '1', '1', '1', '1');
INSERT INTO `model` VALUES ('2', '咨询师经理', '0', '', '9', '1', '1', '11', '1');
INSERT INTO `model` VALUES ('5', '用户管理', '1', 'YonghuFile', '10', null, null, null, null);
INSERT INTO `model` VALUES ('6', '模块管理', '1', 'ModelFile', '8', null, null, null, null);
INSERT INTO `model` VALUES ('7', '角色管理', '1', 'RolesFile', '9', null, null, null, null);
INSERT INTO `model` VALUES ('8', '网络咨询师', '2', '', '4', null, null, null, null);
INSERT INTO `model` VALUES ('9', '咨询师', '2', '', '2', null, null, null, null);
INSERT INTO `model` VALUES ('10', '员工签到', '2', 'YuanGQFile', '1', null, null, null, null);
INSERT INTO `model` VALUES ('13', '网络学生', '8', 'StudentFile', '1', null, null, null, null);
INSERT INTO `model` VALUES ('14', '分量设置', '2', 'FenliangFile', '2', null, null, null, null);
INSERT INTO `model` VALUES ('16', '我的学生', '9', 'getStudent', '2', null, null, null, null);
INSERT INTO `model` VALUES ('20', '网络跟踪', '9', 'getXueshenghuifang', '1', null, null, null, null);
INSERT INTO `model` VALUES ('50', '咨询师管理', '2', 'QuanzhongguanliFile', '1', null, null, null, null);

-- ----------------------------
-- Table structure for modelroles
-- ----------------------------
DROP TABLE IF EXISTS `modelroles`;
CREATE TABLE `modelroles` (
  `mr_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_id` int(11) DEFAULT NULL,
  `m_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`mr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of modelroles
-- ----------------------------
INSERT INTO `modelroles` VALUES ('70', '5', '7');
INSERT INTO `modelroles` VALUES ('82', '1', '1');
INSERT INTO `modelroles` VALUES ('83', '1', '5');
INSERT INTO `modelroles` VALUES ('84', '1', '6');
INSERT INTO `modelroles` VALUES ('85', '1', '7');
INSERT INTO `modelroles` VALUES ('86', '1', '2');
INSERT INTO `modelroles` VALUES ('87', '1', '8');
INSERT INTO `modelroles` VALUES ('88', '1', '13');
INSERT INTO `modelroles` VALUES ('89', '1', '9');
INSERT INTO `modelroles` VALUES ('90', '1', '16');
INSERT INTO `modelroles` VALUES ('91', '1', '20');
INSERT INTO `modelroles` VALUES ('92', '1', '10');
INSERT INTO `modelroles` VALUES ('93', '1', '14');
INSERT INTO `modelroles` VALUES ('110', '4', '2');
INSERT INTO `modelroles` VALUES ('111', '4', '8');
INSERT INTO `modelroles` VALUES ('112', '4', '13');
INSERT INTO `modelroles` VALUES ('130', '3', '2');
INSERT INTO `modelroles` VALUES ('131', '3', '9');
INSERT INTO `modelroles` VALUES ('132', '3', '16');
INSERT INTO `modelroles` VALUES ('133', '3', '20');
INSERT INTO `modelroles` VALUES ('134', '2', '2');
INSERT INTO `modelroles` VALUES ('135', '2', '8');
INSERT INTO `modelroles` VALUES ('136', '2', '13');
INSERT INTO `modelroles` VALUES ('137', '2', '9');
INSERT INTO `modelroles` VALUES ('138', '2', '16');
INSERT INTO `modelroles` VALUES ('139', '2', '20');
INSERT INTO `modelroles` VALUES ('140', '2', '10');
INSERT INTO `modelroles` VALUES ('141', '2', '14');
INSERT INTO `modelroles` VALUES ('142', '2', '50');

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `r_name` varchar(255) DEFAULT NULL,
  `exitInt` int(11) DEFAULT NULL,
  `exitString` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES ('1', '管理员', null, null);
INSERT INTO `roles` VALUES ('2', '咨询师经理', null, null);
INSERT INTO `roles` VALUES ('3', '咨询师', null, null);
INSERT INTO `roles` VALUES ('4', '网络咨询师', null, null);
INSERT INTO `roles` VALUES ('6', '哈哈哈', null, null);
INSERT INTO `roles` VALUES ('7', '客服', null, null);

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `stu_id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_name` varchar(255) DEFAULT NULL,
  `stu_sex` varchar(255) DEFAULT NULL,
  `stu_age` int(11) DEFAULT NULL,
  `stu_tel` varchar(255) DEFAULT NULL,
  `stu_xueli` varchar(255) DEFAULT NULL,
  `stu_State` int(11) DEFAULT NULL,
  `stu_sourcer` varchar(255) DEFAULT NULL,
  `stu_site` varchar(255) DEFAULT NULL,
  `stu_qq` varchar(255) DEFAULT NULL,
  `stu_weiXin` varchar(255) DEFAULT NULL,
  `stu_reported` int(255) DEFAULT NULL,
  `stu_note` varchar(255) DEFAULT NULL,
  `stu_Address` varchar(255) DEFAULT NULL,
  `y_id` int(11) DEFAULT NULL,
  `p_class` varchar(255) DEFAULT NULL,
  `p_validity` int(255) DEFAULT NULL,
  `p_whyValidity` varchar(255) DEFAULT NULL,
  `p_score` int(11) DEFAULT NULL,
  `p_isReturn` int(11) DEFAULT NULL,
  `p_firstReturnTime` date DEFAULT NULL,
  `p_isTheDoor` varchar(255) DEFAULT NULL,
  `p_timeTheDoor` date DEFAULT NULL,
  `p_isPay` varchar(255) DEFAULT NULL,
  `p_payTime` date DEFAULT NULL,
  `p_price` double DEFAULT NULL,
  `p_isRefund` varchar(255) DEFAULT NULL,
  `p_isClass` varchar(255) DEFAULT NULL,
  `p_classTime` date DEFAULT NULL,
  `p_classNote` varchar(255) DEFAULT NULL,
  `p_whyRefund` varchar(255) DEFAULT NULL,
  `p_deposit` double DEFAULT NULL,
  `p_depositTime` date DEFAULT NULL,
  `rouleNote` varchar(255) DEFAULT NULL,
  `stu_loadTime` date DEFAULT NULL,
  `w_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('1', '张旭', '男', '21', '15237862615', '未知', '3', '自然流量', '高考站', '26599349', '17344782766', '1', '在线备注', '郑州', '3', '课程方向', '1', '无效', '9', '0', '2019-05-15', '是', '2019-05-12', '已缴费', '2019-05-13', '6300', '否', '是', '2019-04-30', '无备注', '无', '900', '2019-05-08', '咨询师备注', '2019-05-16', '4');
INSERT INTO `student` VALUES ('2', 'pwb', '女', '19', '15893860199', '高中', '0', '360移动端', '职英B站', '12315', '2165', '1', '啊', '郑州', '3', '计算机', '1', '有效', '8', '0', '2019-05-03', '是', '2019-05-12', '已缴费', '2019-05-13', '6300', '否', '是', '2019-05-13', '无备注', '无', '900', '2019-05-08', '咨询师备注', '2019-05-16', '14');
INSERT INTO `student` VALUES ('3', '周西亚', '男', '25', '18573158465', '本科', '3', '搜狗', '高考站', '131231', '213123', '0', '是', '天津', '3', '机电', '2', '无效', '10', '0', '2019-05-03', '是', '2019-05-12', '已缴费', '2019-05-13', '6300', '否', '是', '2019-05-13', '无备注', '无', '900', '2019-04-29', '咨询师备注', '2019-05-16', '4');
INSERT INTO `student` VALUES ('4', 'PDD', '男', '29', '15893841615', '初中', '0', 'UC移动端', '未知', '115025416', 'Lin16842', '2', '主播', '晋中', '3', '美术', '1', '有效', '9', '0', '2019-05-03', '是', '2019-05-12', '已缴费', '2019-05-13', '6300', '否', '是', '2019-05-13', '无备注', '无', '900', '2019-05-08', '咨询师备注', '2019-05-16', '14');
INSERT INTO `student` VALUES ('5', 'SKT T1', '女', '18', '18761581111', '小学', '1', '360移动端', '网易', '151861', 'STK81651', '1', '护臂', '石家庄', '3', '体育', '1', '有效', '8', '0', '2019-05-03', '是', '2019-05-12', '已缴费', '2019-05-13', '6300', '否', '是', '2019-05-13', '无备注', '无', '900', '2019-05-08', '咨询师备注', '2019-05-16', '14');
INSERT INTO `student` VALUES ('6', '快乐风男', '男', '21', '15555566666', '博士', '0', '网易', '网易', '5615795', 'qq131584', '1', '卡其', '上海', '3', '电竞', '1', '有效', '7', '0', '2019-05-03', '是', '2019-05-12', '已缴费', '2019-05-15', '6300', '否', '是', '2019-05-13', '无备注', '无', '900', '2019-05-08', '咨询师备注', '2019-05-16', '1');
INSERT INTO `student` VALUES ('7', '提莫', '男', '30', '18777777777', '大专', '1', '腾讯', '职英B站', '9024189', 'ss156184', '1', '阿卡丽', '北京', '3', '航海', '2', '无效', '10', '0', '2019-05-03', '是', '2019-05-12', '已缴费', '2019-05-13', '6300', '否', '是', '2019-05-15', '无备注', '无', '900', '2019-05-08', '咨询师备注', '2019-05-16', '4');
INSERT INTO `student` VALUES ('8', '欧米伽小分队', '女', '60', '15666666666', '初中', '1', '腾讯', '腾讯', '9848498', 'bzdq51631', '1', '奥尔兰烤翅', '杭州', '3', '幼师', '1', '有效', '8', '1', '2019-05-03', '是', '2019-05-12', '已缴费', '2019-05-13', '6300', '否', '是', '2019-05-13', '无备注', '无', '900', '2019-05-08', '咨询师备注', '2019-05-16', '1');
INSERT INTO `student` VALUES ('9', '花木兰', '女', '21', '13777777777', '高中', '1', '其他', '其他', '561846', 'qqq1111', '0', '克罗', '苏州', '3', '化学', '2', '无效', '9', '1', '2019-05-03', '是', '2019-05-17', '已缴费', '2019-05-13', '6300', '否', '是', '2019-05-13', '无备注', '无', '900', '2019-05-08', '咨询师备注', '2019-05-16', '14');
INSERT INTO `student` VALUES ('10', '放逐之刃', '女', '22', '18699999999', '大专', '3', '其他', '其他', '651846', 'asdwasd88', '2', '雷比', '郑州', '3', '物理', '1', '有效', '9', '1', '2019-05-03', '是', '2019-05-12', '已缴费', '2019-05-13', '6300', '否', '是', '2019-05-13', '无备注', '无', '900', '2019-05-08', '咨询师备注', '2019-05-16', '1');
INSERT INTO `student` VALUES ('11', '艾瑞利亚', '女', '18', '15602863526', '博士', '0', 'lol', '英雄联盟', '123456526', '15862659562', '0', '艾欧尼亚', '1', '19', '2222', '1', '1', '1', '1', '2019-05-14', '否', '2019-05-12', '已缴费', '2019-05-13', '2100', '是', '否', '2019-05-06', 'asdf', 'asdf', '2100', '2019-05-22', 'asdfsadf', '2019-05-18', '1');
INSERT INTO `student` VALUES ('25', '老王', '男', '12', '1234234235', '大专', '2', '百度移动端', '高考站', '2353452345', '235325346', '1', '帅哥', 'asdfasd', '19', 'asdf', '2', 'asdfass', '2', '2', '2019-05-14', '否', null, null, null, null, null, null, null, null, null, null, null, null, null, '14');
INSERT INTO `student` VALUES ('32', '某某', '女', '21', '21', '未知', '2', '360', '高考站', '2134124', '21423141234', '1', '安达港', null, '16', null, '2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '2019-05-30', '16');
INSERT INTO `student` VALUES ('33', '孙德祥一号', '男', '19', '1231231231', '未知', '0', '未知', '未知', '123123123', '112313', '1', 'sadsda', '1', '20', '1', '1', '无效', '1', '1', '2019-05-30', '1', '2019-05-13', '1', null, '1', '1', '1', '2019-06-04', '1', '1', '21', '2019-05-07', null, '2019-05-30', '17');
INSERT INTO `student` VALUES ('35', '老李', '男', '21', '123143141', '高中', '0', '百度移动端', '职英B站', '2342352', '235235', '1', '梵蒂冈', '阿斯蒂芬干啥', '18', '阿士大夫撒旦', '1', '阿士大夫撒上', '6', '2', '2019-05-16', '否', '2019-05-14', '未缴费', '2019-05-13', '21', '是', '是', '2019-05-07', '撒旦法', '阿萨德噶', '21', '2019-05-06', 'asdfas', '2019-05-31', '18');
INSERT INTO `student` VALUES ('36', '老张', '女', '21', '134124123', '高中', '2', '百度移动端', '职英B站', '2314324', '234235', '0', '水电费敢死队', '河南省', '19', 'java', '2', 'adsfsaf', '4', '2', '2019-05-15', '否', '2019-05-20', '已缴费', '2019-05-06', '21111', '是', '否', '2019-05-14', 'dsgdsf', 'asdf', '21', '2019-05-22', 'asdfasf', '2019-05-31', '19');
INSERT INTO `student` VALUES ('37', '老张2', '男', '21', '124124124', '中专', '3', '百度', '职英B站', '235234234', '2342352352', '0', '帅哥', '河南', '20', 'Java', '2', '有效', '6', '1', '2019-06-14', '否', '2019-06-03', '未缴费', '2019-05-29', '2111', '否', '是', '2019-06-10', '帅哥', '无', '2111', '2019-06-12', '老张2', '2019-06-02', '20');

-- ----------------------------
-- Table structure for xueshenghuifang
-- ----------------------------
DROP TABLE IF EXISTS `xueshenghuifang`;
CREATE TABLE `xueshenghuifang` (
  `t_id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` int(11) DEFAULT NULL,
  `y_id` int(11) DEFAULT NULL,
  `t_visitTime` date DEFAULT NULL,
  `t_Revisit` varchar(255) DEFAULT NULL,
  `t_method` varchar(255) DEFAULT NULL,
  `t_nextTraceTime` date DEFAULT NULL,
  `t_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xueshenghuifang
-- ----------------------------
INSERT INTO `xueshenghuifang` VALUES ('4', '4', '1', '2019-05-02', '优质', '电话', '2019-05-21', '不错');
INSERT INTO `xueshenghuifang` VALUES ('5', '5', '4', '2019-05-03', '良好', '电话', '2019-05-14', '说话很幽默');
INSERT INTO `xueshenghuifang` VALUES ('6', '6', '3', '2019-05-05', '差', '电话', '2019-05-15', '虎');
INSERT INTO `xueshenghuifang` VALUES ('7', '7', '1', '2019-05-08', '优质', 'qq', '2019-05-15', '有私人问题');
INSERT INTO `xueshenghuifang` VALUES ('8', '8', '4', '2019-05-08', '良好', 'qq', '2019-05-15', '说话很幽默');
INSERT INTO `xueshenghuifang` VALUES ('9', '8', '3', '2019-05-08', '差', 'qq', '2019-05-15', '说话很幽默');
INSERT INTO `xueshenghuifang` VALUES ('10', '9', '1', '2019-05-08', '优质', '其他', '2019-05-15', '有私人问题');
INSERT INTO `xueshenghuifang` VALUES ('11', '10', '4', '2019-05-08', '良好', '其他', '2019-05-15', '虎');
INSERT INTO `xueshenghuifang` VALUES ('12', '11', '3', '2019-05-08', '差', '其他', '2019-05-15', '有私人问题');
INSERT INTO `xueshenghuifang` VALUES ('16', '2', '2', '2019-05-20', 'H哈哈哈', 'qq', '2019-05-21', '哈哈哈啊');
INSERT INTO `xueshenghuifang` VALUES ('17', '1', '1', '2019-05-07', '略略略', 'qq', '2019-05-29', '略略略');
INSERT INTO `xueshenghuifang` VALUES ('18', '2', '2', '2019-05-05', 'llllll', 'qq', '2019-05-22', '啦啦啦L');
INSERT INTO `xueshenghuifang` VALUES ('19', '13', '3', '2019-05-14', 'HHAHA ', 'qq', '2019-05-23', 'HHAHHA');
INSERT INTO `xueshenghuifang` VALUES ('20', '13', '1', '2019-05-06', 'HAHAHHA ', '电话', '2019-05-17', 'HHAHA');
INSERT INTO `xueshenghuifang` VALUES ('21', '2', '2', '2019-05-01', 'SSS', '电话', '2019-05-22', 'SSS');
INSERT INTO `xueshenghuifang` VALUES ('22', '13', '5', '2019-05-01', '还好', '电话', '2019-05-30', '还好');
INSERT INTO `xueshenghuifang` VALUES ('24', '1', '3', '2019-05-14', '1', '电话', '2019-05-15', '1');
INSERT INTO `xueshenghuifang` VALUES ('25', '25', '3', '2019-05-15', 'asdf', '微信', '2019-05-07', 'asdf');
INSERT INTO `xueshenghuifang` VALUES ('26', '36', '19', '2019-05-15', '长得很帅', '微信', '2019-05-09', '大帅哥');

-- ----------------------------
-- Table structure for yonghu
-- ----------------------------
DROP TABLE IF EXISTS `yonghu`;
CREATE TABLE `yonghu` (
  `y_id` int(11) NOT NULL AUTO_INCREMENT,
  `y_name` varchar(255) DEFAULT NULL,
  `y_password` varchar(255) DEFAULT NULL,
  `y_email` varchar(255) DEFAULT NULL,
  `y_lastLoginTime` datetime DEFAULT NULL,
  `y_tel` varchar(255) DEFAULT NULL,
  `y_createTime` datetime DEFAULT NULL,
  `y_pasdWrongShu` int(11) DEFAULT NULL,
  `y_isLockout` int(11) DEFAULT NULL,
  `y_weight` int(11) DEFAULT NULL,
  `y_yanzhengma` varchar(255) DEFAULT NULL,
  `y_resetPassword` varchar(255) DEFAULT NULL,
  `yq_state` int(11) DEFAULT NULL,
  `yq_startTime` datetime DEFAULT NULL,
  `yq_endTime` datetime DEFAULT NULL,
  PRIMARY KEY (`y_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yonghu
-- ----------------------------
INSERT INTO `yonghu` VALUES ('1', '用户老张', 'd776be771e34293953d66ebc052d0524', '123@qq.com', '2019-06-02 23:40:09', '18439449536', '2019-05-07 15:55:53', '0', '2', '21', '1', 'd776be771e34293953d66ebc052d0524', '3', '2019-06-03 10:31:25', '2019-06-03 10:31:18');
INSERT INTO `yonghu` VALUES ('3', '用户老孙', 'd776be771e34293953d66ebc052d0524', '2@qq.com', '2019-06-02 23:40:13', '18439449536', '2019-05-14 15:55:53', '0', '2', '3', '1', 'd776be771e34293953d66ebc052d0524', '1', '2019-05-17 08:12:11', '2019-05-17 08:12:16');
INSERT INTO `yonghu` VALUES ('4', '用户张旭', 'd776be771e34293953d66ebc052d0524', '123@qq.com', '2019-05-20 14:24:59', '123523523523523', '2019-06-08 15:55:53', '0', '2', '1', '1', 'd776be771e34293953d66ebc052d0524', '1', '2019-05-20 10:09:26', '2019-05-17 08:12:26');
INSERT INTO `yonghu` VALUES ('5', '用户王华伟', 'd776be771e34293953d66ebc052d0524', '123@qq.com', '2019-06-02 23:26:30', '18439449536', '2019-06-09 15:55:53', '0', '2', '1', '1', 'd776be771e34293953d66ebc052d0524', '1', '2019-05-20 10:09:31', '2019-05-16 14:53:10');
INSERT INTO `yonghu` VALUES ('8', '用户tom', 'd776be771e34293953d66ebc052d0524', '2@qq.com', '2019-05-20 14:25:11', '22342352', '2019-05-13 15:06:39', '0', '1', '1', null, 'd776be771e34293953d66ebc052d0524', '1', '2019-05-20 10:09:35', '2019-05-20 10:09:39');
INSERT INTO `yonghu` VALUES ('9', '用户风男', 'd776be771e34293953d66ebc052d0524', '123@qq.com', '2019-06-02 23:26:38', '18439449536', '2019-05-13 15:11:26', '0', '1', '2', null, 'd776be771e34293953d66ebc052d0524', '2', '2019-05-16 14:51:07', '2019-05-16 14:53:13');
INSERT INTO `yonghu` VALUES ('10', '用户哈撒给', 'd776be771e34293953d66ebc052d0524', '1@qq.com', '2019-05-20 14:23:41', '18439449536', '2019-05-13 15:14:44', '0', '1', '1', null, 'd776be771e34293953d66ebc052d0524', '4', '2019-05-16 14:51:07', '2019-05-16 14:53:15');
INSERT INTO `yonghu` VALUES ('11', '用户giao哥', 'c81e728d9d4c2f636f067f89cc14862c', '2@qq.com', '2019-05-16 09:45:50', '18439449536', '2019-05-13 15:17:17', '0', '1', '1', null, 'd776be771e34293953d66ebc052d0524', '1', '2019-05-16 14:51:07', '2019-05-16 14:53:17');
INSERT INTO `yonghu` VALUES ('12', '用户行为艺术家', 'c4ca4238a0b923820dcc509a6f75849b', '1@qq.com', '2019-05-15 13:17:51', '18439449536', '2019-05-13 15:18:57', '0', '1', '1', null, 'd776be771e34293953d66ebc052d0524', '3', '2019-05-18 18:07:31', '2019-05-18 18:07:32');
INSERT INTO `yonghu` VALUES ('19', '老张', 'd776be771e34293953d66ebc052d0524', '1@qq.com', '2019-05-31 14:31:14', '18439449536', '2019-05-31 14:31:14', '0', '1', '1', null, 'd776be771e34293953d66ebc052d0524', '4', null, '2019-06-02 16:28:10');
INSERT INTO `yonghu` VALUES ('20', '老张2', 'd776be771e34293953d66ebc052d0524', '1@qq.com', '2019-06-02 10:23:56', '18439449536', '2019-06-02 10:23:56', '0', '2', '4', null, 'd776be771e34293953d66ebc052d0524', '3', '2019-06-02 10:25:45', null);

-- ----------------------------
-- Table structure for yonghujuese
-- ----------------------------
DROP TABLE IF EXISTS `yonghujuese`;
CREATE TABLE `yonghujuese` (
  `yr_id` int(11) NOT NULL AUTO_INCREMENT,
  `y_id` int(11) DEFAULT NULL,
  `r_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`yr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of yonghujuese
-- ----------------------------
INSERT INTO `yonghujuese` VALUES ('11', '2', '2');
INSERT INTO `yonghujuese` VALUES ('19', '4', '4');
INSERT INTO `yonghujuese` VALUES ('28', '6', '6');
INSERT INTO `yonghujuese` VALUES ('29', '7', '7');
INSERT INTO `yonghujuese` VALUES ('36', '8', '2');
INSERT INTO `yonghujuese` VALUES ('37', '9', '3');
INSERT INTO `yonghujuese` VALUES ('38', '3', '5');
INSERT INTO `yonghujuese` VALUES ('39', '1', '5');
INSERT INTO `yonghujuese` VALUES ('40', '5', '5');
INSERT INTO `yonghujuese` VALUES ('42', '1', '1');
INSERT INTO `yonghujuese` VALUES ('43', '3', '3');
INSERT INTO `yonghujuese` VALUES ('44', '5', '2');
INSERT INTO `yonghujuese` VALUES ('46', '1', '2');
INSERT INTO `yonghujuese` VALUES ('67', '20', '4');
INSERT INTO `yonghujuese` VALUES ('68', '20', '3');

-- ----------------------------
-- Table structure for zidongfenpei
-- ----------------------------
DROP TABLE IF EXISTS `zidongfenpei`;
CREATE TABLE `zidongfenpei` (
  `f_id` int(11) DEFAULT NULL,
  `fenpeizhuangtai` varchar(11) NOT NULL,
  PRIMARY KEY (`fenpeizhuangtai`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of zidongfenpei
-- ----------------------------
INSERT INTO `zidongfenpei` VALUES ('1', '否');
