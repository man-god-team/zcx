package com.crm.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.crm.entity.Dongtaixinxi;
import com.crm.entity.Fenye;
import com.crm.entity.Yonghu;
import com.crm.service.DongtaixinxiService;

@Controller
public class DongtaixinxiController {
	
	@Autowired
	private DongtaixinxiService dongtaixinxiService;
//	������̬��Ϣ 
	@RequestMapping(value="/fasongdongtai",method=RequestMethod.POST)
	@ResponseBody
		public Integer fasongdongtai(Dongtaixinxi dongtaixinxi) { 
		 
		SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			    String time = df.format(new Date()).toString();
			
			dongtaixinxi.setDt_time(time);
			dongtaixinxi.setDt_state(1);
			System.out.println(dongtaixinxi);
			return dongtaixinxiService.insertintoDongtaixinxi(dongtaixinxi);
		}
//	չʾ��̬��Ϣ 
	@RequestMapping(value="/Showfasongdongtai",method=RequestMethod.POST)
	@ResponseBody
	public Fenye<Dongtaixinxi> Showfasongdongtai(HttpSession session,Integer page,Integer rows) { 
		
		 Fenye<Dongtaixinxi> fenye=new Fenye<Dongtaixinxi>();
		 fenye.setPage((page-1)*rows);
		 fenye.setPageSize(rows);
		 
		 Yonghu yonghu=(Yonghu)session.getAttribute("yonghu"); 
			fenye.setDt_yid(yonghu.getY_id());
			 
		 
		 List<Dongtaixinxi> selectDongtaixinxiByY_id = dongtaixinxiService.selectDongtaixinxiByY_id(fenye);
		 Integer selectDongtaixinxiCount = dongtaixinxiService.selectDongtaixinxiCount(fenye);
		 fenye.setRows(selectDongtaixinxiByY_id);
		 fenye.setTotal(selectDongtaixinxiCount);
		 
		return fenye;
	}
//	չʾ��ʷ��̬��Ϣ 
	@RequestMapping(value="/Showfasongdongtailishixiaoxi",method=RequestMethod.POST)
	@ResponseBody
	public Fenye<Dongtaixinxi> Showfasongdongtailishixiaoxi(HttpSession session,Integer page,Integer rows) { 
		
		Fenye<Dongtaixinxi> fenye=new Fenye<Dongtaixinxi>();
		fenye.setPage((page-1)*rows);
		fenye.setPageSize(rows);
		
		Yonghu yonghu=(Yonghu)session.getAttribute("yonghu");
		  
		fenye.setDt_yid(yonghu.getY_id());
	 
		
		List<Dongtaixinxi> selectDongtaixinxiByY_id = dongtaixinxiService.selectDongtailishixinxiByY_id(fenye);
		Integer selectDongtaixinxiCount = dongtaixinxiService.selectDongtailishixinxiCount(fenye);
		fenye.setRows(selectDongtaixinxiByY_id);
		fenye.setTotal(selectDongtaixinxiCount);
		
		return fenye;
	}
//	�޸Ķ�̬��Ϣ 
	@RequestMapping(value="/deletefasongdongtai",method=RequestMethod.POST)
	@ResponseBody
		public Integer deletefasongdongtai(Dongtaixinxi dongtaixinxi) {  
			return dongtaixinxiService.deleteDongtaixinxi(dongtaixinxi);
		}
//	ɾ����̬��Ϣ deletelishixinxi
	@RequestMapping(value="/deletelishixinxi",method=RequestMethod.POST)
	@ResponseBody
	public Integer deletelishixinxi(Dongtaixinxi dongtaixinxi) {  
		return dongtaixinxiService.deletelishixinxi(dongtaixinxi);
	}
	
}
