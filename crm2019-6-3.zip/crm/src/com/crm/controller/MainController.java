package com.crm.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.crm.entity.Dongtaixinxi;
import com.crm.entity.Fenye;
import com.crm.entity.Models;
import com.crm.entity.Yonghu;
import com.crm.service.DongtaixinxiService;
import com.crm.service.ModelService;
import com.crm.service.RolesService;
 

@Controller
public class MainController {
	@Autowired
	private  ModelService modelService;
	@Autowired
	private  RolesService rolesService;
	@Autowired
	private  DongtaixinxiService dongtaixinxiService;
	
	@RequestMapping(value="/selectdonttaiIscunzai",method = RequestMethod.POST)
	@ResponseBody
	public Integer selectdonttaiIscunzai(HttpSession session) {
		Fenye<Dongtaixinxi> fenye=new Fenye<Dongtaixinxi>();
		
		Yonghu yonghu=(Yonghu)session.getAttribute("yonghu");
		  
		fenye.setDt_yid(yonghu.getY_id());
		   Integer selectDongtaixinxiByY_id = dongtaixinxiService.selectDongtaixinxiCount(fenye);
		   if(selectDongtaixinxiByY_id >0) {
			   return 1;
		   }else { 
			   return 0;
		   }
		
	 
	}
	
//	��ԃģ�锵���@ʾ
	@RequestMapping(value=("/showmain"),method=RequestMethod.POST)
	@ResponseBody 
	public List<Models> showmain(HttpSession session){ 
		
		  Object attribute = session.getAttribute("yonghu");
		  Yonghu yh=(Yonghu)attribute ;
		   
//			��ѯ���û��Ƿ�Ϊ����Ա���ߣ���ѯʦ����ְλ
		  Integer roles = rolesService.selectRolesByY_id(yh);
//		  ��ѯ���û��Ƿ�Ϊ������ѯʦ
		  Integer wangluozixunshi=rolesService.selectRolesByR_nameAndY_id(yh);
//	 ��ѯ���û��Ƿ�Ϊ��ѯʦ
		  Integer zixunshi=rolesService.selectRolesIszixunshiByR_nameAndY_id(yh); 
		  
		  session.setAttribute("zixunshi", zixunshi);
		  session.setAttribute("wangluozixunshi", wangluozixunshi); 
		  session.setAttribute("rolesInt", roles);
		  
		  
		  System.out.println(1);
		  System.out.println(yh);
		return modelService.selectModelByY_name(yh);
	}
	
	@RequestMapping(value="/tuichu",method = RequestMethod.POST)
	@ResponseBody
	public Integer tuichu(HttpSession session) {
		Yonghu yonghu=(Yonghu)session.getAttribute("yonghu");
		  session.invalidate();
		 return 1;
	 
	}
}
