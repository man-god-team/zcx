package com.crm.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.crm.entity.Fenye;
import com.crm.entity.Modelroles;
import com.crm.entity.Roles;
import com.crm.entity.Student;
import com.crm.entity.Yonghu;
import com.crm.entity.Zidongfenpei;
import com.crm.service.StudentService;
import com.crm.service.YonghuService;
import com.crm.service.ZidongfenpeiService;
import com.crm.util.QuanZhongFenPei;

@Controller
public class StudentController {
  
	@Autowired
	private StudentService studentService;
	@Autowired
	private YonghuService yonghuService;
	@Autowired
	private ZidongfenpeiService zidongfenpeiServiceImp;
//	��ѯ��������

	@RequestMapping(value="/selectAllByZidongfenpei",method=RequestMethod.POST)
	@ResponseBody
	public String selectAllByZidongfenpei(){ 
		Zidongfenpei selectAllByZidongfenpei2 = zidongfenpeiServiceImp.selectAllByZidongfenpei();
		
		return selectAllByZidongfenpei2.getFenpeizhuangtai();
	}
	
	
//	ѧ������֮���Զ�����
	@RequestMapping(value="/updateStudentByzidongfenpei",method=RequestMethod.POST)
	@ResponseBody
	public Integer updateStudentByzidongfenpei(){
		Student student=new Student();

		//		��ѯ���һ������
		Student selectOneByOrderBy = studentService.selectOneByOrderBy();
		
		Yonghu yonghu=new Yonghu();
		yonghu.setR_name("��ѯʦ");
		List<Yonghu> selectYonghuAllBynone = yonghuService.selectYonghuAllBynone(yonghu);
		 
		
		
		QuanZhongFenPei quanZhongFenPei=new QuanZhongFenPei();
		Yonghu yonghu2 = quanZhongFenPei.fenpei(selectYonghuAllBynone);


		yonghu2.getY_id();
		student.setY_id(yonghu2.getY_id());
		
		student.setStu_id(selectOneByOrderBy.getStu_id());
	 
		return studentService.updateStudent(student);
		
	}
//	ѧ���Զ����� ��ť�Ƿ��Զ�����
	@RequestMapping(value="/updateZidongfenpei1",method=RequestMethod.POST)
	@ResponseBody
	public Integer updateZidongfenpei1(Zidongfenpei zidongfenpei){
 
		return zidongfenpeiServiceImp.updateZidongfenpei(zidongfenpei);
		
	}
//	ѧ������
	 @RequestMapping(value="/UpdateStudentByFP",method=RequestMethod.POST)
	    @ResponseBody
	    public Integer UpdateStudentByFP(Student student){
	     
			return studentService.updateStudent(student);
	    	
	    }
	 
	@RequestMapping(value="/selectAllByfenpei",method=RequestMethod.POST)
	@ResponseBody
	public Fenye<Student> selectAllByfenpei(Integer page, Integer rows) {
	Fenye<Student> fenye=new Fenye<Student>(); 
		fenye.setPage((page-1)*rows);
		fenye.setPageSize(rows);
		List<Student> selectAllByfenpei = yonghuService.selectAllByfenpei(fenye);
		Integer selectStudentCount = yonghuService.selectStudentCount(fenye);
		fenye.setTotal(selectStudentCount);
		fenye.setRows(selectAllByfenpei);
		return fenye;
	}
	@RequestMapping(value="/selectYonghuByR_id",method=RequestMethod.POST)
	@ResponseBody
	public List<Yonghu> selectYonghuByR_id() {
		Yonghu yonghu =new Yonghu();
		return yonghuService.selectYonghuByR_id(yonghu);
	}
	
	@RequestMapping(value="/selectStudent",method=RequestMethod.POST)
	@ResponseBody
	public Fenye<Student> selectStudent(Student student, Integer page, Integer rows) {
		Fenye<Student> fenye=new Fenye<Student>();
	
		fenye.setStudent(student);
		fenye.setPage((page-1)*rows);
		fenye.setPageSize(rows);
		fenye=studentService.selectStudent(fenye);
		return fenye;
		
	}
	
	 @RequestMapping(value="/updateStudent",method=RequestMethod.POST)
	    @ResponseBody
	    public Integer updateStudent(Student student){
	    	
			return studentService.updateStudent(student);
	    	
	    }

	 @RequestMapping(value="/deleteStudent",method=RequestMethod.POST)
	    @ResponseBody
	    public Integer deleteStudent(Integer stu_id,String y_id){
		 Student student=new Student();
		 student.setStu_id(stu_id);
		 if(y_id != null && y_id!="") {
			 return 0;
		 }else {
			 return studentService.deleteStudent(student);
		 }
			
	    }


	 @RequestMapping(value="/addStudent",method=RequestMethod.POST)
	    @ResponseBody
	    public Integer addStudent(Student student){
		 
			SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				    String time = df.format(new Date()).toString();
				 
	    	student.setStu_loadTime(time);
			return studentService.addStudent(student);
	    	
	    }
 
		
//		
		@RequestMapping(value = "/getALL", method = RequestMethod.POST)
		@ResponseBody
		public Fenye<Student> getALL(Integer page, Integer rows, Student student,
				String listA, String timeMax, String timeMix) {
			
			Fenye<Student> fenye=new Fenye<Student>();
			fenye.setPage((page - 1) * rows);
			fenye.setPageSize(rows);
			fenye.setT(student);
			fenye.setTimeMax(timeMax);
			fenye.setTimeMix(timeMix);
			fenye.setListA(listA);
			fenye.setStudent(student);
			Integer selectCount = studentService.selectCount(fenye);
			List<Student> selectAllStudent = studentService.selectAllStudent(fenye);
			
			fenye.setTotal(selectCount);
			fenye.setRows(selectAllStudent);
			return fenye;
		}

		@RequestMapping(value = "/updateA", method = RequestMethod.POST)
		@ResponseBody
		public Integer updateA(Student student) {
			Fenye<Student> fenye=new Fenye<Student>();
			 
			fenye.setT(student);
			Integer updataStudentByid = studentService.updataStudentByid(student);
			System.out.println(updataStudentByid);
			return updataStudentByid;
		}

		/* ��ѯʦ����ɾ����Чѧ��  */
		@RequestMapping(value = "/deleteStudentByZixunshijingli", method = RequestMethod.POST)
		@ResponseBody
		public Integer deleteStudentByZixunshijingli(Student student) {
			
			Integer deleteStudent = studentService.deleteStudent(student);

			return deleteStudent;
		}
		/* ��ѯʦ���������޸�ѧ��������ѯʦ   */
		@RequestMapping(value = "/UpdateStudentByY_idandStu_id", method = RequestMethod.POST)
		@ResponseBody
		public Integer UpdateStudentByY_idandStu_id(String stu_idStu,String y_id) {
			if(stu_idStu!=null && stu_idStu!="") {
				String[] split = stu_idStu.split(",");
				System.out.println(split.length+",,,,,,"+1);
				
				for (int i = 0; i < split.length; i++) {
					Student student=new Student();
					student.setStu_id(Integer.parseInt(split[i]));
					student.setY_id(Integer.parseInt(y_id));
					studentService.UpdateStudentByY_idandStu_id(student);
				}

				return 1;
			}else {
				 return 0;
			} 
			
		}
}
