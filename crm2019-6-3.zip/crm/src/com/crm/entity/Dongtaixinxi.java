package com.crm.entity;

public class Dongtaixinxi {
	private Integer dt_id;//��̬��Ϣid
	private String dt_studentName;//ѧ������
	private String dt_time;//����ʱ��
	private Integer dt_yid;//������id
	private String dt_content;//��Ϣ����
	private Integer dt_state;//��Ϣ״̬
	private Integer dt_int1;//Ԥ��int�ֶ�
	private String dt_string2;//Ԥ��string�ֶ�
	
	
	private Yonghu yonghu;
	
	public Yonghu getYonghu() {
		return yonghu;
	}
	public void setYonghu(Yonghu yonghu) {
		this.yonghu = yonghu;
	}
	public Integer getDt_id() {
		return dt_id;
	}
	public void setDt_id(Integer dt_id) {
		this.dt_id = dt_id;
	}
	public String getDt_studentName() {
		return dt_studentName;
	}
	public void setDt_studentName(String dt_studentName) {
		this.dt_studentName = dt_studentName;
	}
	public String getDt_time() {
		return dt_time;
	}
	public void setDt_time(String dt_time) {
		this.dt_time = dt_time;
	}
	public Integer getDt_yid() {
		return dt_yid;
	}
	public void setDt_yid(Integer dt_yid) {
		this.dt_yid = dt_yid;
	}
	public String getDt_content() {
		return dt_content;
	}
	public void setDt_content(String dt_content) {
		this.dt_content = dt_content;
	}
	public Integer getDt_state() {
		return dt_state;
	}
	public void setDt_state(Integer dt_state) {
		this.dt_state = dt_state;
	}
	public Integer getDt_int1() {
		return dt_int1;
	}
	public void setDt_int1(Integer dt_int1) {
		this.dt_int1 = dt_int1;
	}
	public String getDt_string2() {
		return dt_string2;
	}
	public void setDt_string2(String dt_string2) {
		this.dt_string2 = dt_string2;
	}
	@Override
	public String toString() {
		return "Dongtaixinxi [dt_id=" + dt_id + ", dt_studentName=" + dt_studentName + ", dt_time=" + dt_time
				+ ", dt_yid=" + dt_yid + ", dt_content=" + dt_content + ", dt_state=" + dt_state + ", dt_int1="
				+ dt_int1 + ", dt_string2=" + dt_string2 + "]";
	}


}
