package com.crm.entity;

public class Yonghujuese {
	private Integer yr_id;
	private Integer y_id;
	private Integer r_id;
	public Integer getYr_id() {
		return yr_id;
	}
	public void setYr_id(Integer yr_id) {
		this.yr_id = yr_id;
	}
	public Integer getY_id() {
		return y_id;
	}
	public void setY_id(Integer y_id) {
		this.y_id = y_id;
	}
	public Integer getR_id() {
		return r_id;
	}
	public void setR_id(Integer r_id) {
		this.r_id = r_id;
	}
	@Override
	public String toString() {
		return "Yonghujuese [yr_id=" + yr_id + ", y_id=" + y_id + ", r_id=" + r_id + "]";
	}


}
