package com.crm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crm.dao.DongtaixinxiMapper;
import com.crm.entity.Dongtaixinxi;
import com.crm.entity.Fenye;
@Service
public class DongtaixinxiServiceImp  implements DongtaixinxiService{
	
	@Autowired
	private DongtaixinxiMapper dongtaixinxiMapper;

	@Override
	public List<Dongtaixinxi> selectDongtaixinxiByY_id(Fenye<Dongtaixinxi> fenye) {
		// TODO Auto-generated method stub
		return dongtaixinxiMapper.selectDongtaixinxiByY_id(fenye);
	}

	@Override
	public Integer selectDongtaixinxiCount(Fenye<Dongtaixinxi> fenye) {
		// TODO Auto-generated method stub
		return dongtaixinxiMapper.selectDongtaixinxiCount(fenye);
	}

	@Override
	public Integer insertintoDongtaixinxi(Dongtaixinxi dongtaixinxi) {
		// TODO Auto-generated method stub
		return dongtaixinxiMapper.insertintoDongtaixinxi(dongtaixinxi);
	}

	@Override
	public Integer deleteDongtaixinxi(Dongtaixinxi dongtaixinxi) {
		// TODO Auto-generated method stub
		return dongtaixinxiMapper.deleteDongtaixinxi(dongtaixinxi);
	}

	@Override
	public List<Dongtaixinxi> selectDongtailishixinxiByY_id(Fenye<Dongtaixinxi> fenye) {
		// TODO Auto-generated method stub
		return dongtaixinxiMapper.selectDongtailishixinxiByY_id(fenye);
	}

	@Override
	public Integer selectDongtailishixinxiCount(Fenye<Dongtaixinxi> fenye) {
		// TODO Auto-generated method stub
		return dongtaixinxiMapper.selectDongtailishixinxiCount(fenye);
	}

	@Override
	public Integer deletelishixinxi(Dongtaixinxi dongtaixinxi) {
		// TODO Auto-generated method stub
		return dongtaixinxiMapper.deletelishixinxi(dongtaixinxi);
	}

}
