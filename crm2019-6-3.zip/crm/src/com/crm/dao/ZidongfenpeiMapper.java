package com.crm.dao; 
import com.crm.entity.Zidongfenpei;

public interface ZidongfenpeiMapper {
	 
	Zidongfenpei selectAllByZidongfenpei();
	Integer updateZidongfenpei(Zidongfenpei zidongfenpei);

}
