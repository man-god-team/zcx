package com.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.crm.dao.StudentMapper;
import com.crm.entity.Fenye;
import com.crm.entity.Student;
import com.crm.service.StudentService;

@Controller
public class StudentController {
	@Autowired
	private Fenye<Student> fenye;

	@Autowired
	private StudentService studentService;

	@RequestMapping(value = "/getALL", method = RequestMethod.POST)
	@ResponseBody
	public Fenye<Student> getALL(Integer page, Integer rows, Student student,
			String listA, String timeMax, String timeMix) {
		fenye.setPage((page - 1) * rows);
		fenye.setPageSize(rows);
		fenye.setT(student);
		fenye.setTimeMax(timeMax);
		fenye.setTimeMix(timeMix);
		fenye.setListA(listA);
		
		Integer selectCount = studentService.selectCount(fenye);
		List<Student> selectAllStudent = studentService.selectAllStudent(fenye);
		
		fenye.setTotal(selectCount);
		fenye.setRows(selectAllStudent);
		return fenye;
	}

	@RequestMapping(value = "/updateA", method = RequestMethod.POST)
	@ResponseBody
	public Integer updateA(Student student) {
		System.out.println(5566);
		fenye.setT(student);
		Integer updataStudentByid = studentService.updataStudentByid(student);
		System.out.println(updataStudentByid);
		return updataStudentByid;
	}

	@RequestMapping(value = "/detelteA", method = RequestMethod.POST)
	@ResponseBody
	public Integer detelteA(Integer stu_id) {
		
		Integer deleteStudent = studentService.deleteStudent(stu_id);

		return deleteStudent;
	}

}
