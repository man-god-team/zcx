package com.crm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crm.dao.StudentMapper;
import com.crm.entity.Fenye;
import com.crm.entity.Student;

@Service
public class StudentServiceImp implements StudentService {
	@Autowired
	private StudentMapper studentMapper;

	@Override
	public Integer selectCount(Fenye fenye) {
		// TODO Auto-generated method stub
		return studentMapper.selectCount(fenye);
	}

	@Override
	public List<Student> selectAllStudent(Fenye fenye) {
		// TODO Auto-generated method stub
	
		return studentMapper.selectAllStudent(fenye);
	}

	@Override
	public Integer updataStudentByid(Student student) {
		// TODO Auto-generated method stub
		System.out.println(student);
		return studentMapper.updataStudentByid(student);
	}

	@Override
	public Integer deleteStudent(Integer stu_id) {
		// TODO Auto-generated method stub
		return studentMapper.deleteStudent(stu_id);
	}

}
