package com.crm.entity;

import org.springframework.stereotype.Component;

@Component
public class Yonghu {
	private Integer y_id;
	private String y_name;
	public Integer getY_id() {
		return y_id;
	}
	public void setY_id(Integer y_id) {
		this.y_id = y_id;
	}
	public String getY_name() {
		return y_name;
	}
	public void setY_name(String y_name) {
		this.y_name = y_name;
	}
	@Override
	public String toString() {
		return "Yonghu [y_id=" + y_id + ", y_name=" + y_name + "]";
	}
	
}
