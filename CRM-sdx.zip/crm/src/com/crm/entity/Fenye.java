package com.crm.entity;

import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class Fenye<T> {
	private Integer page;
	private Integer pageSize;
	private Integer total;
	private List<T> rows;
	private T t;
	
	//�������-�������
	private String stu_name;			//ѧ������
	private String y_name;				//�û�����
	private String t_visitTime;			//�ط�ʱ��
	private String t_nextTraceTime;		//�´θ���ʱ��
	private String t_Revisit;			//�ط����
	private String t_method;			//���ٷ�ʽ
	
	
	
	private String listA;
	private String timeMix;
	private String timeMax;
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	public List<T> getRows() {
		return rows;
	}
	public void setRows(List<T> rows) {
		this.rows = rows;
	}
	public T getT() {
		return t;
	}
	public void setT(T t) {
		this.t = t;
	}
	public String getStu_name() {
		return stu_name;
	}
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}
	public String getY_name() {
		return y_name;
	}
	public void setY_name(String y_name) {
		this.y_name = y_name;
	}
	public String getT_visitTime() {
		return t_visitTime;
	}
	public void setT_visitTime(String t_visitTime) {
		this.t_visitTime = t_visitTime;
	}
	public String getT_nextTraceTime() {
		return t_nextTraceTime;
	}
	public void setT_nextTraceTime(String t_nextTraceTime) {
		this.t_nextTraceTime = t_nextTraceTime;
	}
	public String getT_Revisit() {
		return t_Revisit;
	}
	public void setT_Revisit(String t_Revisit) {
		this.t_Revisit = t_Revisit;
	}
	public String getT_method() {
		return t_method;
	}
	public void setT_method(String t_method) {
		this.t_method = t_method;
	}
	public String getListA() {
		return listA;
	}
	public void setListA(String listA) {
		this.listA = listA;
	}
	public String getTimeMix() {
		return timeMix;
	}
	public void setTimeMix(String timeMix) {
		this.timeMix = timeMix;
	}
	public String getTimeMax() {
		return timeMax;
	}
	public void setTimeMax(String timeMax) {
		this.timeMax = timeMax;
	}
	@Override
	public String toString() {
		return "Fenye [page=" + page + ", pageSize=" + pageSize + ", total="
				+ total + ", rows=" + rows + ", t=" + t + ", stu_name="
				+ stu_name + ", y_name=" + y_name + ", t_visitTime="
				+ t_visitTime + ", t_nextTraceTime=" + t_nextTraceTime
				+ ", t_Revisit=" + t_Revisit + ", t_method=" + t_method
				+ ", listA=" + listA + ", timeMix=" + timeMix + ", timeMax="
				+ timeMax + "]";
	}
	
	
	
	
}
